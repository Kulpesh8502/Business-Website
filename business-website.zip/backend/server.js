const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 5000;

// Simple health check
app.get('/api/health', (req, res) => res.json({status: 'ok'}));

// Contact form endpoint
app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email and message are required' });
  }

  // NOTE: For real projects, replace transporter config with environment variables and a real SMTP provider.
  const transporter = nodemailer.createTransport({
    host: 'smtp.example.com',
    port: 587,
    secure: false,
    auth: { user: 'user@example.com', pass: 'password' }
  });

  const mailOptions = {
    from: '"Website Contact" <no-reply@example.com>',
    to: 'owner@example.com',
    subject: `New contact from ${name}`,
    text: `Name: ${name}\nEmail: ${email}\nMessage:\n${message}`
  };

  try {
    // transporter.sendMail(mailOptions) // commented out by default to avoid errors
    console.log('Contact received:', mailOptions);
    res.json({ success: true, message: 'Contact received (email sending disabled in template).' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to send email' });
  }
});

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));

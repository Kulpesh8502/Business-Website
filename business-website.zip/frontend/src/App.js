import React, {useState} from 'react';
import axios from 'axios';

export default function App(){
  const [form, setForm] = useState({name:'', email:'', message:''});
  const [status, setStatus] = useState(null);

  const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

  const submit = async e => {
    e.preventDefault();
    setStatus('sending');
    try {
      const res = await axios.post('http://localhost:5000/api/contact', form);
      setStatus('sent');
    } catch (err) {
      setStatus('error');
    }
  };

  return (
    <div style={{fontFamily:'sans-serif',maxWidth:900,margin:'2rem auto',padding:'1rem'}}>
      <header style={{textAlign:'center',marginBottom:20}}>
        <h1>Acme Consulting</h1>
        <p>Expert solutions for small and medium businesses.</p>
      </header>

      <section style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:20}}>
        <div>
          <h2>About Us</h2>
          <p>Acme Consulting helps businesses grow with digital strategy, design and engineering.</p>

          <h3>Services</h3>
          <ul>
            <li>Web & Mobile Development</li>
            <li>Brand & Design</li>
            <li>Cloud & DevOps</li>
          </ul>
        </div>

        <aside style={{border:'1px solid #ddd',padding:16,borderRadius:8}}>
          <h3>Contact Us</h3>
          <form onSubmit={submit}>
            <div style={{marginBottom:8}}>
              <input name="name" placeholder="Your name" value={form.name} onChange={handleChange} style={{width:'100%',padding:8}}/>
            </div>
            <div style={{marginBottom:8}}>
              <input name="email" placeholder="Email" value={form.email} onChange={handleChange} style={{width:'100%',padding:8}}/>
            </div>
            <div style={{marginBottom:8}}>
              <textarea name="message" placeholder="Message" value={form.message} onChange={handleChange} style={{width:'100%',padding:8}}/>
            </div>
            <button type="submit" style={{padding:'8px 12px'}}>Send</button>
          </form>
          {status === 'sending' && <p>Sending...</p>}
          {status === 'sent' && <p style={{color:'green'}}>Message sent! (simulated)</p>}
          {status === 'error' && <p style={{color:'red'}}>Failed to send.</p>}
        </aside>
      </section>

      <footer style={{textAlign:'center',marginTop:40,color:'#666'}}>
        © {new Date().getFullYear()} Acme Consulting
      </footer>
    </div>
  );
}

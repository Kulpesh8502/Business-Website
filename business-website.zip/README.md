# Business Website Project

Simple business website (React frontend) with an Express backend for contact form handling.

## Structure
- frontend/ - React app (Create React App style)
- backend/  - Express server for form submissions

## Run locally

### Backend
```bash
cd backend
npm install
node server.js
```

### Frontend
```bash
cd frontend
npm install
npm start
```

The frontend expects backend on port 5000 by default.

## Notes
This is a minimal starter project. You can upload this folder to GitHub to create your repo.
